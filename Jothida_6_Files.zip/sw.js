/* Service worker — ஒருமுறை திறந்தபின் இணையம் இல்லாமலும் ஓடும் */
const CACHE='jothida-v2';   /* புதிய index.html ஏற்றும்போது இந்த எண்ணை v2, v3 என மாற்றவும் */
const FILES=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  const u=new URL(e.request.url);
  if(u.origin!==location.origin)return;                 /* வெளி (CDN) கோரிக்கைகளை தொடாது */
  e.respondWith(
    fetch(e.request).then(r=>{const c=r.clone();caches.open(CACHE).then(x=>x.put(e.request,c));return r})   /* இணையம் இருந்தால் புதியது */
      .catch(()=>caches.match(e.request).then(r=>r||caches.match('./index.html')))                         /* இல்லையெனில் சேமித்தது */
  );
});
